package com.example.mortezasaadat.animalquiz;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class AksaraKunoFragment extends Fragment {


    public AksaraKunoFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.word_list,container,false);
        ArrayList<Aksara> aksaraKuno = new ArrayList<Aksara>();
        aksaraKuno.add(new Aksara("Ba",R.drawable.aksara_kuno_ba));
        aksaraKuno.add(new Aksara("Ca",R.drawable.aksara_kuno_ca));
        aksaraKuno.add(new Aksara("Da",R.drawable.aksara_kuno_da));
        aksaraKuno.add(new Aksara("Ga",R.drawable.aksara_kuno_ga));
        aksaraKuno.add(new Aksara("Ha",R.drawable.aksara_kuno_ha));
        aksaraKuno.add(new Aksara("ja",R.drawable.aksara_kuno_ja));
        aksaraKuno.add(new Aksara("Ka",R.drawable.aksara_kuno_ka));
        aksaraKuno.add(new Aksara("Ma",R.drawable.aksara_kuno_ma));
        aksaraKuno.add(new Aksara("Na",R.drawable.aksara_kuno_na));
        aksaraKuno.add(new Aksara("Nga",R.drawable.aksara_kuno_nga));
        aksaraKuno.add(new Aksara("Nya",R.drawable.aksara_kuno_nya));
        aksaraKuno.add(new Aksara("Pa",R.drawable.aksara_kuno_pa));
        aksaraKuno.add(new Aksara("Nya",R.drawable.aksara_kuno_nya));
        aksaraKuno.add(new Aksara("Ra",R.drawable.aksara_kuno_ra));
        aksaraKuno.add(new Aksara("Sa",R.drawable.aksara_kuno_sa));
        aksaraKuno.add(new Aksara("Ta",R.drawable.aksara_kuno_ta));
        aksaraKuno.add(new Aksara("Ya",R.drawable.aksara_kuno_ya));

        AksaraAdapter adapter = new
                AksaraAdapter(getActivity(),aksaraKuno);
        ListView listView = (ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        return rootView;
    }

}
