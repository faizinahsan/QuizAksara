package com.example.mortezasaadat.animalquiz;

import android.app.Activity;

import java.util.ArrayList;

/**
 * Created by M FaizinAhsan on 4/23/2018.
 */

public class Aksara {
    private String aksaraTranslation;
    private int mImageResourceId = NO_IMAGE_PROVIDED;
    private static final  int NO_IMAGE_PROVIDED = -1;

    public int getImageResourceId() {
        return mImageResourceId;
    }

    public Aksara(String aksaraTranslation, int mImageResourceId) {
        this.aksaraTranslation = aksaraTranslation;
        this.mImageResourceId = mImageResourceId;
    }
    public String getAksaraTranslation() {
        return aksaraTranslation;
    }

    public int getmImageResourceId() {
        return mImageResourceId;
    }
    //    Return whether or not there is an image
    public boolean hasImage(){
        return mImageResourceId != NO_IMAGE_PROVIDED;
    }

}
