package com.example.mortezasaadat.animalquiz;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class AksaraBakuFragment extends Fragment {


    public AksaraBakuFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.word_list,container,false);
        ArrayList<Aksara> aksaraBaku = new ArrayList<Aksara>();
        aksaraBaku.add(new Aksara("Ba",R.drawable.aksara_baku_ba));
        aksaraBaku.add(new Aksara("Ca",R.drawable.aksara_baku_ca));
        aksaraBaku.add(new Aksara("Da",R.drawable.aksara_baku_da));
        aksaraBaku.add(new Aksara("Fa",R.drawable.aksara_baku_fa));
        aksaraBaku.add(new Aksara("Ga",R.drawable.aksara_baku_ga));
        aksaraBaku.add(new Aksara("Ha",R.drawable.aksara_baku_ha));
        aksaraBaku.add(new Aksara("Ja",R.drawable.aksara_baku_ja));
        aksaraBaku.add(new Aksara("Ka",R.drawable.aksara_baku_ka));
        aksaraBaku.add(new Aksara("Kha",R.drawable.aksara_baku_kha));
        aksaraBaku.add(new Aksara("La",R.drawable.aksara_baku_la));
        aksaraBaku.add(new Aksara("Ma",R.drawable.aksara_baku_ma));
        aksaraBaku.add(new Aksara("Na",R.drawable.aksara_baku_na));
        aksaraBaku.add(new Aksara("Nga",R.drawable.aksara_baku_nga));
        aksaraBaku.add(new Aksara("Nya",R.drawable.aksara_baku_nya));
        aksaraBaku.add(new Aksara("Pa",R.drawable.aksara_baku_pa));
        aksaraBaku.add(new Aksara("Qa",R.drawable.aksara_baku_qa));
        aksaraBaku.add(new Aksara("Sa",R.drawable.aksara_baku_sa));
        aksaraBaku.add(new Aksara("Sya",R.drawable.aksara_baku_sya));
        aksaraBaku.add(new Aksara("Ta",R.drawable.aksara_baku_ta));
        aksaraBaku.add(new Aksara("Va",R.drawable.aksara_baku_va));
        aksaraBaku.add(new Aksara("Wa",R.drawable.aksara_baku_wa));
        aksaraBaku.add(new Aksara("Xa",R.drawable.aksara_baku_xa));
        aksaraBaku.add(new Aksara("Ya",R.drawable.aksara_baku_ya));
        AksaraAdapter adapter = new
                AksaraAdapter(getActivity(),aksaraBaku);
        ListView listView = (ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);

        return rootView;
    }

}
