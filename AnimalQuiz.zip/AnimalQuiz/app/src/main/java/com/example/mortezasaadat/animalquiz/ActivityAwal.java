package com.example.mortezasaadat.animalquiz;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ActivityAwal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_awal);
        Button quizAksara = (Button) findViewById(R.id.quiz_aksara);
        quizAksara.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ActivityAwal.this, MainActivity.class);
                startActivity(i);
            }
        });
        Button pengenalanAksara = (Button) findViewById(R.id.pengenalan_aksara);
        pengenalanAksara.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ActivityAwal.this,BelajarAksara.class);
                startActivity(i);
            }
        });
    }
}
